Game.registerMod("EnableParty",{
	init:function(){
		Game.PARTY = 1;
	}
});
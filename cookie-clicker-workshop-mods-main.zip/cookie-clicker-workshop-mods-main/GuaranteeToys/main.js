Game.registerMod("Guarantee Toys",{
	init:function(){
		Game.TOYS = 1;
	}
});
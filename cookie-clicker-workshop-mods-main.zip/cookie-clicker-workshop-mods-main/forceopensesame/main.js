Game.registerMod("Guarantee Open Sesame",{
	init:function(){
		Game.OpenSesame();
	}
});